<!DOCTYPE html>
<html>
  <head>
    <title>Chess</title>
    <link rel="stylesheet" href="css/chessboard-0.3.0.min.css">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="js/chessboard-0.3.0.min.js"></script>
  </head>
  <body>
       <?php require 'navBar.php';?>
    <div id="board1" style="width: 400px"></div>
    <script>
		var cfg = {
			draggable: true,
			dropOffBoard: 'snapback', // this is the default
			position: 'start'
		};
        var board1 = ChessBoard('board1', cfg);
    </script>
      
 
  </body>
</html>